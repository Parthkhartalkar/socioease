# Socioease — Society Management System v5 (Final)

## What's New in v5
- ✅ Watchman / Security Guard portal (full)
- ✅ Gate pass generation (printable)
- ✅ Visitor entry/exit log
- ✅ Parcel / courier tracking
- ✅ Cinema-style visitor parking map (user + watchman)
- ✅ Emergency alert system (notifies all residents by email)
- ✅ Admin notification bell (real-time)
- ✅ Watchman notification bell
- ✅ Admin can create/manage watchman accounts
- ✅ All dates shown as dd/mm/yyyy
- ✅ Society Details page (renamed from Manage Secretary)
- ✅ Booking history shows user-relative row numbers
- ✅ Clean database — no test data

---

## Login URLs

| Role      | URL                   | Credentials               |
|-----------|-----------------------|---------------------------|
| Resident  | `login.php`           | Register via form         |
| Admin     | `Adminlogin.php`      | Admin / 100               |
| Watchman  | `watchman_login.php`  | Created by admin in Manage Watchmen |

---

## Setup

1. Copy `socioease/` folder to `htdocs/`
2. phpMyAdmin → Import → `database.sql`
3. Open `config.php` — fill in:
   - Gmail + App Password for SMTP
   - Razorpay Key Secret
4. Download PHPMailer from GitHub → rename folder to `PHPMailer` → place inside `socioease/`
5. Copy your `Images/` folder into `socioease/`
6. Open `http://localhost/socioease/login.php`

---

## 17 Database Tables

| Table | Purpose |
|-------|---------|
| admin | Admin credentials |
| registration | Residents |
| watchmen | Watchman accounts |
| password_resets | Password reset tokens |
| notifications | All notifications (user/admin/watchman) |
| login_attempts | Rate limiting |
| notices | Society notices |
| combox | Complaints |
| payrecords | Payment records |
| society_details | Secretary info + maintenance amount |
| staff_members | Society staff |
| facilities | Facility list |
| facility_bookings | Facility bookings |
| visitor_parking | Visitor parking bookings |
| visitor_log | Watchman visitor entry/exit |
| parcel_log | Watchman parcel tracking |
| emergency_log | Emergency alerts |

---

## Security Features
- bcrypt password hashing
- CSRF tokens on all forms
- Prepared statements (SQL injection prevention)
- Session timeout (30 minutes)
- Rate limiting (5 attempts → 15 min lockout)
- Email verification on registration
- .htaccess blocks config/include files
- Role-based access control (admin/user/watchman)
