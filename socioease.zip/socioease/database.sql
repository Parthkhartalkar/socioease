-- =============================================================
--  Socioease — Complete Database v5 (Final)
--  17 Tables | Clean slate | All features included
-- =============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `usersregister`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `usersregister`;

-- -----------------------------------------------------------
-- 1. ADMIN
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin` (
  `id`       INT(11)      NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `password` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin` (`id`, `username`, `password`) VALUES (1, 'Admin', '100');

-- -----------------------------------------------------------
-- 2. REGISTRATION (Residents)
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `registration` (
  `Id`                   INT(11)       NOT NULL AUTO_INCREMENT,
  `Username`             VARCHAR(50)   NOT NULL,
  `Email`                VARCHAR(100)  NOT NULL,
  `Flatno`               INT(10)       NOT NULL,
  `MobileNo`             BIGINT(15)    NOT NULL,
  `No_of_family_members` INT(10)       NOT NULL DEFAULT 1,
  `Password`             VARCHAR(255)  NOT NULL,
  `maintenance_balance`  DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `is_verified`          TINYINT(1)    NOT NULL DEFAULT 0,
  `verification_token`   VARCHAR(64)   DEFAULT NULL,
  `created_at`           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Id`),
  INDEX `idx_username`           (`Username`),
  INDEX `idx_flatno`             (`Flatno`),
  INDEX `idx_verification_token` (`verification_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 3. WATCHMEN
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `watchmen` (
  `id`         INT(11)      NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(100) NOT NULL,
  `username`   VARCHAR(50)  NOT NULL UNIQUE,
  `password`   VARCHAR(255) NOT NULL,
  `mobile`     VARCHAR(15)  NOT NULL,
  `shift`      ENUM('Morning','Evening','Night') NOT NULL DEFAULT 'Morning',
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 4. PASSWORD RESETS
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `password_resets` (
  `id`         INT(11)      NOT NULL AUTO_INCREMENT,
  `username`   VARCHAR(50)  NOT NULL,
  `flatno`     INT(10)      NOT NULL,
  `email`      VARCHAR(100) NOT NULL,
  `token`      VARCHAR(64)  NOT NULL,
  `expires_at` DATETIME     NOT NULL,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_token`  (`token`),
  INDEX `idx_username`   (`username`),
  INDEX `idx_expires`    (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 5. NOTIFICATIONS (user + admin + watchman)
--    role column separates whose bell it appears in
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`         INT(11)      NOT NULL AUTO_INCREMENT,
  `username`   VARCHAR(100) NOT NULL,
  `role`       VARCHAR(20)  NOT NULL DEFAULT 'user',
  `message`    VARCHAR(500) NOT NULL,
  `type`       VARCHAR(30)  NOT NULL DEFAULT 'general',
  `link`       VARCHAR(255) DEFAULT NULL,
  `is_read`    TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_username_role` (`username`, `role`),
  INDEX `idx_is_read`       (`username`, `is_read`),
  INDEX `idx_created`       (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 6. LOGIN ATTEMPTS
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id`           INT(11)     NOT NULL AUTO_INCREMENT,
  `ip_address`   VARCHAR(45) NOT NULL,
  `attempts`     INT(5)      NOT NULL DEFAULT 1,
  `last_attempt` TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ip`       (`ip_address`),
  INDEX `idx_last_attempt` (`last_attempt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 7. NOTICES
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notices` (
  `ID`         INT(11)      NOT NULL AUTO_INCREMENT,
  `Name`       VARCHAR(100) NOT NULL,
  `Type`       VARCHAR(20)  NOT NULL,
  `Noticedate` DATE         NOT NULL,
  `Message`    VARCHAR(500) NOT NULL,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 8. COMPLAINTS
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `combox` (
  `ID`         INT(11)      NOT NULL AUTO_INCREMENT,
  `Title`      VARCHAR(150) NOT NULL,
  `complaint`  TEXT         NOT NULL,
  `image_path` VARCHAR(255) NOT NULL DEFAULT '',
  `status`     VARCHAR(50)  NOT NULL DEFAULT 'Pending',
  `username`   VARCHAR(100) NOT NULL DEFAULT '',
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  INDEX `idx_username` (`username`),
  INDEX `idx_status`   (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 9. PAYMENT RECORDS
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payrecords` (
  `ID`         INT(11)       NOT NULL AUTO_INCREMENT,
  `Name`       VARCHAR(100)  NOT NULL,
  `Flatno`     INT(11)       NOT NULL,
  `month_name` VARCHAR(20)   DEFAULT NULL,
  `Amount`     DECIMAL(10,2) NOT NULL,
  `utr_number` VARCHAR(50)   DEFAULT NULL,
  `Status`     VARCHAR(100)  NOT NULL DEFAULT 'Pending',
  `created_at` TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  INDEX `idx_flatno` (`Flatno`),
  INDEX `idx_status` (`Status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 10. SOCIETY DETAILS
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `society_details` (
  `id`              INT(11)       NOT NULL AUTO_INCREMENT,
  `name`            VARCHAR(100)  NOT NULL,
  `updated_at`      TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mobile_number`   VARCHAR(15)   DEFAULT NULL,
  `email_address`   VARCHAR(255)  DEFAULT NULL,
  `address`         TEXT          DEFAULT NULL,
  `maintenance_amt` INT(11)       NOT NULL DEFAULT 1500,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 11. STAFF MEMBERS
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `staff_members` (
  `id`         INT(11)      NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(100) NOT NULL,
  `mobile`     VARCHAR(15)  NOT NULL,
  `email`      VARCHAR(100) DEFAULT NULL,
  `address`    TEXT         DEFAULT NULL,
  `role`       VARCHAR(50)  NOT NULL,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 12. FACILITIES
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `facilities` (
  `facility_id`    INT(11)      NOT NULL AUTO_INCREMENT,
  `facility_name`  VARCHAR(100) NOT NULL,
  `description`    TEXT         DEFAULT NULL,
  `available_from` TIME         DEFAULT NULL,
  `available_to`   TIME         DEFAULT NULL,
  `slot_type`      VARCHAR(20)  NOT NULL DEFAULT '2hour',
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`facility_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `facilities`
  (`facility_id`,`facility_name`,`description`,`available_from`,`available_to`,`slot_type`) VALUES
(1,'Community Hall',  'Multipurpose hall for events, meetings and gatherings.','06:00:00','00:00:00','6hour'),
(2,'Tennis Court',    'Outdoor tennis court with lighting for evening play.',   '06:00:00','22:00:00','2hour'),
(3,'Badminton Court', 'Indoor badminton court.',                                '06:00:00','22:00:00','2hour'),
(4,'Cricket Net',     'Outdoor cricket practice net.',                          '06:00:00','20:00:00','2hour');

-- -----------------------------------------------------------
-- 13. FACILITY BOOKINGS
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `facility_bookings` (
  `id`           INT(11)      NOT NULL AUTO_INCREMENT,
  `facility_id`  INT(11)      NOT NULL,
  `slot_id`      INT(11)      NOT NULL,
  `booking_date` DATE         NOT NULL,
  `user_name`    VARCHAR(100) NOT NULL,
  `flatno`       VARCHAR(50)  DEFAULT NULL,
  `status`       VARCHAR(20)  NOT NULL DEFAULT 'Pending',
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_facility`    (`facility_id`),
  INDEX `idx_user`        (`user_name`),
  INDEX `idx_date_status` (`booking_date`, `status`),
  CONSTRAINT `fk_booking_facility`
    FOREIGN KEY (`facility_id`) REFERENCES `facilities`(`facility_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 14. VISITOR PARKING
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `visitor_parking` (
  `id`             INT(11)       NOT NULL AUTO_INCREMENT,
  `username`       VARCHAR(100)  NOT NULL,
  `flatno`         VARCHAR(20)   NOT NULL,
  `visitor_name`   VARCHAR(100)  NOT NULL,
  `vehicle_no`     VARCHAR(50)   NOT NULL,
  `slots`          INT(11)       NOT NULL DEFAULT 1,
  `start_date`     DATE          NOT NULL,
  `end_date`       DATE          NOT NULL,
  `start_time`     VARCHAR(20)   NOT NULL,
  `end_time`       VARCHAR(20)   NOT NULL,
  `total_hours`    DECIMAL(5,2)  NOT NULL DEFAULT 0,
  `total_price`    DECIMAL(10,2) NOT NULL DEFAULT 0,
  `payment_status` VARCHAR(20)   DEFAULT 'Billed',
  `created_at`     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_flatno`     (`flatno`),
  INDEX `idx_start_date` (`start_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 15. VISITOR LOG (Watchman)
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `visitor_log` (
  `id`             INT(11)      NOT NULL AUTO_INCREMENT,
  `flat_no`        VARCHAR(20)  NOT NULL,
  `resident_name`  VARCHAR(100) NOT NULL,
  `visitor_name`   VARCHAR(100) NOT NULL,
  `visitor_mobile` VARCHAR(15)  DEFAULT NULL,
  `vehicle_no`     VARCHAR(50)  DEFAULT NULL,
  `purpose`        VARCHAR(200) DEFAULT NULL,
  `time_in`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `time_out`       DATETIME     DEFAULT NULL,
  `logged_by`      VARCHAR(50)  NOT NULL,
  `gate_pass_code` VARCHAR(20)  DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `idx_flat`       (`flat_no`),
  INDEX `idx_logged_by`  (`logged_by`),
  INDEX `idx_time_in`    (`time_in`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 16. PARCEL LOG (Watchman)
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `parcel_log` (
  `id`              INT(11)      NOT NULL AUTO_INCREMENT,
  `flat_no`         VARCHAR(20)  NOT NULL,
  `resident_name`   VARCHAR(100) NOT NULL,
  `courier_company` VARCHAR(100) DEFAULT NULL,
  `description`     VARCHAR(200) DEFAULT NULL,
  `received_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `collected_at`    DATETIME     DEFAULT NULL,
  `collected_by`    VARCHAR(100) DEFAULT NULL,
  `logged_by`       VARCHAR(50)  NOT NULL,
  `status`          VARCHAR(20)  NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id`),
  INDEX `idx_flat`      (`flat_no`),
  INDEX `idx_status`    (`status`),
  INDEX `idx_logged_by` (`logged_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- 17. EMERGENCY LOG (Watchman)
-- -----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `emergency_log` (
  `id`          INT(11)      NOT NULL AUTO_INCREMENT,
  `raised_by`   VARCHAR(50)  NOT NULL,
  `alert_type`  VARCHAR(100) NOT NULL,
  `description` TEXT         DEFAULT NULL,
  `location`    VARCHAR(200) DEFAULT NULL,
  `status`      VARCHAR(20)  NOT NULL DEFAULT 'Active',
  `resolved_by` VARCHAR(100) DEFAULT NULL,
  `resolved_at` DATETIME     DEFAULT NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_status`    (`status`),
  INDEX `idx_raised_by` (`raised_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -----------------------------------------------------------
-- AUTO_INCREMENT
-- -----------------------------------------------------------
ALTER TABLE `admin`             MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
ALTER TABLE `registration`      MODIFY `Id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `watchmen`          MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `password_resets`   MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `notifications`     MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `login_attempts`    MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `notices`           MODIFY `ID`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `combox`            MODIFY `ID`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `payrecords`        MODIFY `ID`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `society_details`   MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `staff_members`     MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `facilities`        MODIFY `facility_id` INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
ALTER TABLE `facility_bookings` MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `visitor_parking`   MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `visitor_log`       MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `parcel_log`        MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
ALTER TABLE `emergency_log`     MODIFY `id`          INT NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

COMMIT;
