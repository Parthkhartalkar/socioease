<?php
require 'auth_check_admin.php';

$page_title = "View Payments";
require 'header_admin.php';
require 'sidebar_admin.php';
?>
<div class="main-container" id="main-container">
    <h2 class="page-title">Payment Ledger</h2>

    <div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:10px;padding:14px 18px;margin-bottom:22px;display:flex;align-items:center;gap:10px;">
        <i class="fas fa-bolt" style="color:#059669;font-size:16px;"></i>
        <span style="font-size:14px;color:#166534;font-weight:600;">All payments are auto-verified via Razorpay — no manual approval required.</span>
    </div>

    <div class="table-container">
        <table class="content-table">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Month</th>
                    <th>Resident</th>
                    <th>Flat</th>
                    <th>Transaction ID</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $res = $conn->query("SELECT * FROM payrecords ORDER BY ID DESC");
            $i   = 1;
            while ($row = $res->fetch_assoc()):
                $sc = ($row['Status'] === 'Success') ? 'badge-success' : 'badge-pending';
            ?>
                <tr>
                    <td style="color:#94A3B8;"><?= $i++ ?></td>
                    <td><strong><?= htmlspecialchars($row['month_name']) ?></strong></td>
                    <td><?= htmlspecialchars($row['Name']) ?></td>
                    <td><?= htmlspecialchars($row['Flatno']) ?></td>
                    <td style="font-family:monospace;font-size:13px;color:#5469d4;">
                        <?= htmlspecialchars($row['utr_number'] ?? '-') ?>
                    </td>
                    <td style="font-weight:700;">₹<?= number_format($row['Amount'],2) ?></td>
                    <td><span class="badge <?= $sc ?>"><?= htmlspecialchars($row['Status']) ?></span></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require 'footer.php'; ?>
